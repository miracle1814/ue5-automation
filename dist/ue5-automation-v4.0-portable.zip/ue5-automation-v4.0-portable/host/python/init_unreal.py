# ue5-automation 桥自启（打包生成）
import traceback

try:
    import ue5_bridge

    ue5_bridge.start()
except Exception:
    try:
        import unreal

        unreal.log_error("[ue5-automation] bridge 启动失败:\n" + traceback.format_exc())
    except Exception:
        print("[ue5-automation] bridge 启动失败:\n" + traceback.format_exc())
